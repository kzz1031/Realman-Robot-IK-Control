
"use strict";

let Joint_Max_Speed = require('./Joint_Max_Speed.js');
let Lift_Height = require('./Lift_Height.js');
let Force_Position_State = require('./Force_Position_State.js');
let Joint_Error_Code = require('./Joint_Error_Code.js');
let Arm_IO_State = require('./Arm_IO_State.js');
let ArmState = require('./ArmState.js');
let Lift_Speed = require('./Lift_Speed.js');
let Tool_Digital_Output = require('./Tool_Digital_Output.js');
let Arm_Current_State copy = require('./Arm_Current_State copy.js');
let Servo_GetAngle = require('./Servo_GetAngle.js');
let Hand_Force = require('./Hand_Force.js');
let Plan_State = require('./Plan_State.js');
let Force_Position_Move_Joint = require('./Force_Position_Move_Joint.js');
let GetArmState_Command copy = require('./GetArmState_Command copy.js');
let Joint_Step = require('./Joint_Step.js');
let IO_Update = require('./IO_Update.js');
let Hand_Angle = require('./Hand_Angle.js');
let Set_Realtime_Push = require('./Set_Realtime_Push.js');
let Hand_Posture = require('./Hand_Posture.js');
let Joint_Current = require('./Joint_Current.js');
let Arm_Analog_Output = require('./Arm_Analog_Output.js');
let Tool_IO_State = require('./Tool_IO_State.js');
let ChangeWorkFrame_Name = require('./ChangeWorkFrame_Name.js');
let Hand_Speed = require('./Hand_Speed.js');
let Arm_Current_State = require('./Arm_Current_State.js');
let Servo_Move = require('./Servo_Move.js');
let Start_Multi_Drag_Teach = require('./Start_Multi_Drag_Teach.js');
let Arm_Joint_Speed_Max = require('./Arm_Joint_Speed_Max.js');
let MoveJ = require('./MoveJ.js');
let Pos_Teach = require('./Pos_Teach.js');
let Socket_Command = require('./Socket_Command.js');
let CartePos = require('./CartePos.js');
let CarteFdPose = require('./CarteFdPose.js');
let Arm_Software_Version = require('./Arm_Software_Version.js');
let Stop_Teach = require('./Stop_Teach.js');
let Arm_Pose_Euler = require('./Arm_Pose_Euler.js');
let MoveC = require('./MoveC.js');
let Stop = require('./Stop.js');
let MoveJ_PO = require('./MoveJ_PO.js');
let Cabinet = require('./Cabinet.js');
let Manual_Set_Force_Pose = require('./Manual_Set_Force_Pose.js');
let LiftState = require('./LiftState.js');
let ChangeTool_Name = require('./ChangeTool_Name.js');
let Turtle_Driver = require('./Turtle_Driver.js');
let Gripper_Set = require('./Gripper_Set.js');
let Six_Force = require('./Six_Force.js');
let Set_Force_Position = require('./Set_Force_Position.js');
let MoveJ_P = require('./MoveJ_P.js');
let Hand_Seq = require('./Hand_Seq.js');
let Joint_Teach = require('./Joint_Teach.js');
let Ort_Teach = require('./Ort_Teach.js');
let Joint_Enable = require('./Joint_Enable.js');
let Arm_Digital_Output = require('./Arm_Digital_Output.js');
let MoveL = require('./MoveL.js');
let Gripper_Pick = require('./Gripper_Pick.js');
let Force_Position_Move_Pose = require('./Force_Position_Move_Pose.js');
let ChangeWorkFrame_State = require('./ChangeWorkFrame_State.js');
let JointPos = require('./JointPos.js');
let ChangeTool_State = require('./ChangeTool_State.js');
let GetArmState_Command = require('./GetArmState_Command.js');
let Tool_Analog_Output = require('./Tool_Analog_Output.js');

module.exports = {
  Joint_Max_Speed: Joint_Max_Speed,
  Lift_Height: Lift_Height,
  Force_Position_State: Force_Position_State,
  Joint_Error_Code: Joint_Error_Code,
  Arm_IO_State: Arm_IO_State,
  ArmState: ArmState,
  Lift_Speed: Lift_Speed,
  Tool_Digital_Output: Tool_Digital_Output,
  Arm_Current_State copy: Arm_Current_State copy,
  Servo_GetAngle: Servo_GetAngle,
  Hand_Force: Hand_Force,
  Plan_State: Plan_State,
  Force_Position_Move_Joint: Force_Position_Move_Joint,
  GetArmState_Command copy: GetArmState_Command copy,
  Joint_Step: Joint_Step,
  IO_Update: IO_Update,
  Hand_Angle: Hand_Angle,
  Set_Realtime_Push: Set_Realtime_Push,
  Hand_Posture: Hand_Posture,
  Joint_Current: Joint_Current,
  Arm_Analog_Output: Arm_Analog_Output,
  Tool_IO_State: Tool_IO_State,
  ChangeWorkFrame_Name: ChangeWorkFrame_Name,
  Hand_Speed: Hand_Speed,
  Arm_Current_State: Arm_Current_State,
  Servo_Move: Servo_Move,
  Start_Multi_Drag_Teach: Start_Multi_Drag_Teach,
  Arm_Joint_Speed_Max: Arm_Joint_Speed_Max,
  MoveJ: MoveJ,
  Pos_Teach: Pos_Teach,
  Socket_Command: Socket_Command,
  CartePos: CartePos,
  CarteFdPose: CarteFdPose,
  Arm_Software_Version: Arm_Software_Version,
  Stop_Teach: Stop_Teach,
  Arm_Pose_Euler: Arm_Pose_Euler,
  MoveC: MoveC,
  Stop: Stop,
  MoveJ_PO: MoveJ_PO,
  Cabinet: Cabinet,
  Manual_Set_Force_Pose: Manual_Set_Force_Pose,
  LiftState: LiftState,
  ChangeTool_Name: ChangeTool_Name,
  Turtle_Driver: Turtle_Driver,
  Gripper_Set: Gripper_Set,
  Six_Force: Six_Force,
  Set_Force_Position: Set_Force_Position,
  MoveJ_P: MoveJ_P,
  Hand_Seq: Hand_Seq,
  Joint_Teach: Joint_Teach,
  Ort_Teach: Ort_Teach,
  Joint_Enable: Joint_Enable,
  Arm_Digital_Output: Arm_Digital_Output,
  MoveL: MoveL,
  Gripper_Pick: Gripper_Pick,
  Force_Position_Move_Pose: Force_Position_Move_Pose,
  ChangeWorkFrame_State: ChangeWorkFrame_State,
  JointPos: JointPos,
  ChangeTool_State: ChangeTool_State,
  GetArmState_Command: GetArmState_Command,
  Tool_Analog_Output: Tool_Analog_Output,
};
