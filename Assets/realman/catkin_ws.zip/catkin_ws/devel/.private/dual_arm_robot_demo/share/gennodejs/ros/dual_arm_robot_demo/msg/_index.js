
"use strict";

let ObjectPose = require('./ObjectPose.js');

module.exports = {
  ObjectPose: ObjectPose,
};
